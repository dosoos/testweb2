package com.example.projhect4;

import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.projhect4.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.chromium.net.CronetEngine;
import org.chromium.net.CronetException;
import org.chromium.net.UrlRequest;
import org.chromium.net.UrlResponseInfo;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


/**
 * @Author: yzhang8
 */
public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    EditText walletAddress;
    Button buttonQuery;
    TextView walletTextView;
    TextView balanceTextView;
    ListView listView;
    EditText commentEditText;
    Button buttonComment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        // change action bar title
        Objects.requireNonNull(getSupportActionBar()).setTitle("Ethereum Wallet Checker");

        walletAddress = findViewById(R.id.editText);
        buttonQuery = findViewById(R.id.button);
        walletTextView = findViewById(R.id.textView);
        balanceTextView = findViewById(R.id.textView2);
        listView = findViewById(R.id.listView);
        commentEditText = findViewById(R.id.editTextComm);
        buttonComment = findViewById(R.id.buttonSubmit);

        buttonQuery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("TAG", "onClick: buttonQuery");
                getWalletBalance();
            }
        });

    }

    public void getWalletBalance() {
        String address = walletAddress.getText().toString();
        // check address valid
        if (address.length() != 42) {
            Toast.makeText(getApplicationContext(), "Invalid address", Toast.LENGTH_LONG).show();
            return;
        }
        // call the api http://localhost:8080/server_war_exploded/balance-servlet?address=0xeC68CD160F0d8107304d667bf6Ae81394d8f88be
        // and display the result in the textview
        // {"code":0,"data":{"balance":"706556204762282979648","balance_eth":"706.5563","remarks":[]},"message":"success"}
        // {"code":1,"data":null,"message":"error"}

        CronetEngine.Builder myBuilder = new CronetEngine.Builder(getApplicationContext());
        CronetEngine cronetEngine = myBuilder.build();
        // Create a request
        String url = "http://192.168.50.7:8080/server_war_exploded/balance-servlet?address=" + address;
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {
                Log.d("TAG", "onFailure: " + e.getMessage());
            }

            @Override
            public void onResponse(okhttp3.Call call, Response response) throws IOException {
                String result = response.body().string();
                Log.d("TAG", "onResponse: " + result);
                // {"code":0,"data":{"balance":"706556204762282979648","balance_eth":"706.5563","remarks":[]},"message":"success"}
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        walletTextView.setText("Wallet Address: " + address);
                        // parse json string get balance
                        String balance = "0";
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            JSONObject data = jsonObject.getJSONObject("data");
                            balance = data.getString("balance_eth");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        balanceTextView.setText("Balance: " + balance + " ETH");
                    }
                });
            }
        });

    }

}