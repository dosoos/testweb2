A.[name]
B.https://ethereum-rpc.publicnode.com
D.The application allow user check the balance of an Ethereum address.
E.![Screenshot](./task1a.png)
F.![Screenshot](./task1b.png)