package org.example.model;

public class Extra {

    public String address;

    public String remark;

    public Extra() {
    }

    public Extra(String address, String remark) {
        this.address = address;
        this.remark = remark;
    }

    public String toString() {
        return "Extra{" + "address='" + address + ", remark='" + remark + '}';
    }

}
