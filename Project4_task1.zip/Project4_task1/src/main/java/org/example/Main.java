package org.example;

import org.example.util.Ethereum;

import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;

//TIP 要<b>运行</b>代码，请按 <shortcut actionId="Run"/> 或
// 点击装订区域中的 <icon src="AllIcons.Actions.Execute"/> 图标。
public class Main {
    public static void main(String[] args) throws IOException {
        //TIP 当文本光标位于高亮显示的文本处时按 <shortcut actionId="ShowIntentionActions"/>
        // 查看 IntelliJ IDEA 建议如何修正。
        System.out.println("Welcome use Ethereum balance checker!");

        while (true) {

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Please input your Ethereum address: ");
            String address = br.readLine();

            if (address.isEmpty()) {
                System.out.println("Address can't be empty!");
                continue;
            }

            if (!Ethereum.validateAddress(address)) {
                System.out.println("Invalid Ethereum address! example: 0x8D97689C9818892B700e27F316cc3E41e17fBeb9");
                continue;
            }

            try {
                System.out.println("Fetching Ethereum balance...");
                BigInteger balance = Ethereum.getBalance(address);
                System.out.println("Balance: " + Ethereum.toEther(balance) + " ETH, " + balance + " WEI");
                System.out.println();
            } catch (Exception e) {
                System.out.println("Failed to fetch Ethereum balance: " + e.getMessage());
            }

        }
    }
}