package org.example.util;


import com.mongodb.client.*;
import org.bson.Document;
import org.example.model.Extra;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.mongodb.client.model.Filters.eq;

/**
 * MongoDB util
 * 1. Connect to MongoDB
 * 2. Insert data to MongoDB
 * 3. Query data from MongoDB
 */
public class MongoDB {

    private static String CONNECTION_URI = "mongodb://admin:admin@localhost:27017/";

    private static String DATABASE_NAME = "remark";

    private static String COLLECTION_NAME = "ethereum";

    private static MongoClient mongoClient;

    private static MongoDB instance;

    private MongoDB() {
        mongoClient = MongoClients.create(CONNECTION_URI);
    }

    public static MongoDB getInstance() {
        if (instance == null) {
            instance = new MongoDB();
        }
        return instance;
    }

    /**
     * Insert data to MongoDB
     */
    public boolean insert(String address, String remark) {
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);
        Document doc = new Document("address", address).append("remark", remark);
        collection.insertOne(doc);
        return true;
    }

    public boolean delete(String address) {
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Extra> collection = database.getCollection(COLLECTION_NAME, Extra.class);
        collection.deleteOne(eq("address", address));
        return true;
    }

    public boolean update(String address, String remark) {
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Extra> collection = database.getCollection(COLLECTION_NAME, Extra.class);
        collection.updateOne(eq("address", address), new Document("$set", new Document("remark", remark)));
        return true;
    }

    /**
     * Query data from MongoDB
     */
    public static Extra query(String address) {
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);
        Document document = collection.find(eq("address", address)).first();
        if (document != null) {
            return new Extra(document.getString("address"), document.getString("remark"));
        }
        return null;
    }

    public List<Extra> getAll() {
        MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
        MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);
        FindIterable<Document> documents = collection.find();
        List<Extra> list = new ArrayList<Extra>();
        for (Document document : documents) {
            Extra extra = new Extra(document.getString("address"), document.getString("remark"));
            list.add(extra);
        }
        return list;
    }

}
