package org.example;

import org.example.model.Extra;
import org.example.util.MongoDB;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

/**
 * Remark ethereum address to mongodb
 */
public class Remark {

    public static void main(String[] args) throws IOException {
        System.out.println("Welcome use Ethereum address remark tool!");

        // ls: list all records, add: add new record, update: update record, delete: delete record
        while (true) {
            System.out.println("Please input command: ls, add, query, update, delete");
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String command = br.readLine();

            if (command.equals("ls")) {
                System.out.println("List all records...");
                List<Extra> datas = MongoDB.getInstance().getAll();
                for (Extra data : datas) {
                    System.out.println(data);
                }

            } else if (command.equals("query")) {
                System.out.println("Query record...");
                System.out.print("Please input Ethereum address: ");
                String address = br.readLine();
                Extra data = MongoDB.getInstance().query(address);
                if (data != null) {
                    System.out.println(data);
                } else {
                    System.out.println("No record found!");
                }

            } else if (command.equals("add")) {
                System.out.println("Add new record...");
                System.out.print("Please input Ethereum address: ");
                String address = br.readLine();
                System.out.print("Please input remark: ");
                String remark = br.readLine();
                MongoDB.getInstance().insert(address, remark);

            } else if (command.equals("update")) {
                System.out.println("Update record...");
                System.out.print("Please input Ethereum address: ");
                String address = br.readLine();
                System.out.print("Please input new remark: ");
                String remark = br.readLine();
                MongoDB.getInstance().update(address, remark);

            } else if (command.equals("delete")) {
                System.out.println("Delete record...");
                System.out.print("Please input Ethereum address: ");
                String address = br.readLine();
                MongoDB.getInstance().delete(address);

            } else {
                System.out.println("Invalid command!");
            }

        }
    }

}
