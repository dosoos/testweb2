package org.example.server.model;

/**
 * @Author: yzhang8
 */
public class Balance {

    // {"jsonrpc":"2.0","id":1,"result":"0xba862b54effa"}

    public String jsonrpc;

    public int id;

    public String result;

}
